
  # Stock Discussion Forum Dashboard

  This is a code bundle for Stock Discussion Forum Dashboard. The original project is available at https://www.figma.com/design/73MaCjVSsRizN7qSTscCwR/Stock-Discussion-Forum-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  